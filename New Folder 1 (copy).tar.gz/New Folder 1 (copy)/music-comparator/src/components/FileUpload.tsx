// src/components/FileUpload.tsx

import { useState } from 'react';

// FileUpload component now expects the MusicXML string to pass back
interface FileUploadProps {
    onParse: (xmlString: string) => void;
}

const FileUpload = ({ onParse }: FileUploadProps) => {
    const [file, setFile] = useState<File | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) setFile(file);
    };

    const handleFileUpload = async () => {
        if (!file) return;

        const text = await file.text();
        try {
            onParse(text); // Pass the XML string to the parent component
        } catch (error) {
            console.error('Failed to parse XML:', error);
        }
    };

    return (
        <div>
            <input type="file" onChange={handleFileChange} />
            <button onClick={handleFileUpload}>Upload and Parse</button>
        </div>
    );
};

export default FileUpload;
