import React, { useState, useEffect, useRef } from 'react';
import { OpenSheetMusicDisplay } from 'opensheetmusicdisplay';
import * as Tone from 'tone';
import { PitchDetector } from 'pitchy'; // Use Pitchy for pitch detection
// import 'bootstrap/dist/css/bootstrap.min.css';

interface MusicProps {
    musicXML: string; // MusicXML data
}

const Music = ({ musicXML }: MusicProps) => {
    const [osmd, setOsmd] = useState<any>(null); // OSMD instance for rendering MusicXML
    const [isPlaying, setIsPlaying] = useState(false); // To control play/pause
    const [tempo, setTempo] = useState<number | null>(120); // Tempo from MusicXML
    const [detectedPitch, setDetectedPitch] = useState<string | null>(null); // Detected pitch
    const [isCorrectNote, setIsCorrectNote] = useState<boolean | null>(null); // Match status of detected pitch
    const intervalRef = useRef<any>(null); // Interval for note playback
    const synth = new Tone.Synth().toDestination(); // Tone.js synthesizer
    const audioContext = useRef<Tone.Context>(new Tone.Context()).current; // Audio context for pitch detection

    const analyser = useRef<AnalyserNode | null>(null); // Analyser for microphone input
    const pitchDetector = useRef<PitchDetector<Float32Array> | null>(null); // Pitch detector instance

    useEffect(() => {
        // Initialize OSMD to render MusicXML
        const osmdContainer = document.getElementById('osmdContainer');
        if (!osmdContainer || !musicXML) return;

        const newOsmd = new OpenSheetMusicDisplay('osmdContainer', {
            backend: 'svg',
            drawTitle: false,
            drawPartNames: false,
        });

        newOsmd.load(musicXML).then(() => {
            newOsmd.render();
            setOsmd(newOsmd);
        });

        // Set up microphone for pitch detection
        const setupMicrophone = async () => {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                const micSource = audioContext.createMediaStreamSource(stream);
                analyser.current = audioContext.createAnalyser();
                micSource.connect(analyser.current);
                analyser.current.fftSize = 2048; // Size of FFT bins

                // Set up pitch detector
                const bufferSupplier = (inputLength: number) => new Float32Array(inputLength);
                pitchDetector.current = new PitchDetector<Float32Array>(2048, bufferSupplier);

                // Detect pitch continuously
                const detectPitch = () => {
                    if (pitchDetector.current && analyser.current) {
                        const buffer = new Float32Array(analyser.current.fftSize);
                        analyser.current.getFloatTimeDomainData(buffer);
                        const [pitch] = pitchDetector.current.findPitch(buffer, audioContext.sampleRate);
                        setDetectedPitch(pitch.toString());
                        compareNoteWithMusicXML(pitch); // Compare detected pitch with XML note
                    }
                    requestAnimationFrame(detectPitch);
                };

                detectPitch();
            } catch (err) {
                console.error('Error accessing microphone:', err);
            }
        };

        setupMicrophone();

        return () => {
            if (audioContext.state !== 'closed') {
                audioContext.close();
            }
        };
    }, [musicXML]);

    // Convert frequency (Hz) to musical note (e.g., 440 Hz to 'A4')
    const frequencyToNote = (frequency: number): string => {
        const A4 = 440; // A4 = 440 Hz
        const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
        const hertz = frequency;
        const pitchClass = Math.round(12 * (Math.log(hertz / A4) / Math.log(2))); // C is at 0, C# at 1, etc.
        const octave = Math.floor(pitchClass / 12) + 4; // A4 is the reference, so we start at octave 4
        const noteName = noteNames[(pitchClass + 12) % 12];
        return `${noteName}${octave}`;
    };

    // Compare the detected pitch with the note in MusicXML
    const compareNoteWithMusicXML = (detectedFrequency: number | null) => {
        if (!detectedFrequency || !osmd) return;

        // Convert detected frequency to note name
        const detectedNote = frequencyToNote(detectedFrequency);

        // Extract the current note from the OSMD cursor
        const cursor = osmd.cursor as any;
        const currentNote = cursor.currentNote;

        if (currentNote) {
            const expectedNote = currentNote.pitch.step + currentNote.pitch.octave;

            // Compare the detected pitch with the expected pitch (detectedNote and expectedNote)
            if (detectedNote === expectedNote) {
                setIsCorrectNote(true); // Match detected pitch with expected note
            } else {
                setIsCorrectNote(false); // Mismatch detected pitch with expected note
            }
        }
    };

    // Start playing music with OSMD animation and Tone.js
    const playAnimation = () => {
        if (!osmd) return;

        osmd.cursor.reset();
        (osmd.cursor as any).show();
        setIsPlaying(true);

        const intervalTime = (60 / (tempo || 120)) * 1000; // Convert BPM to milliseconds per beat

        intervalRef.current = setInterval(() => {
            const cursor = osmd.cursor as any;
            if (!cursor.next) {
                cursor.reset();
                cursor.next();
                stopAnimation();
            } else {
                cursor.next();
                const currentNote = cursor.currentNote as any;
                if (currentNote && !currentNote.invisible) {
                    const noteToPlay = currentNote.pitch.step + currentNote.pitch.octave;
                    synth.triggerAttackRelease(noteToPlay, '16n');
                }
            }
        }, intervalTime);
    };

    // Stop playing music and stop the OSMD cursor
    const stopAnimation = () => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
        }
        setIsPlaying(false);
        if (osmd?.cursor) (osmd.cursor as any).hide();
    };

    return (
        <div>
            <h1>MusicXML Sheet Music Renderer</h1>
            <div id="osmdContainer" style={{ width: '100%', height: '300px', border: '1px solid black' }}></div>

            <div>
                {detectedPitch && <p>Detected Frequency: {detectedPitch} Hz</p>}
                {isCorrectNote !== null && (
                    <div
                        style={{
                            height: '50px',
                            backgroundColor: isCorrectNote ? 'green' : 'red',
                            color: 'white',
                            textAlign: 'center',
                            lineHeight: '50px',
                        }}
                    >
                        {isCorrectNote ? 'Correct Note!' : 'Try Again!'}
                    </div>
                )}
            </div>

            <button onClick={isPlaying ? stopAnimation : playAnimation}>{isPlaying ? 'Stop' : 'Play'}</button>
        </div>
    );
};

export default Music;
