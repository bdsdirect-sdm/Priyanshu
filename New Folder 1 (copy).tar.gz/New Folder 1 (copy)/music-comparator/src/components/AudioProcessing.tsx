// src/components/AudioProcessing.tsx

import { useState, useEffect } from 'react';

interface AudioData {
    pitch: string;
    timing: number;
    duration: number;
}

interface AudioProcessingProps {
    onAudioProcessed: (data: AudioData[]) => void;
}

const AudioProcessing = ({ onAudioProcessed }: AudioProcessingProps) => {
    const [audioStream, setAudioStream] = useState<MediaStream | null>(null);
    const [audioData, setAudioData] = useState<AudioData[]>([]);

    useEffect(() => {
        if (audioStream) {
            const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
            const analyser = audioContext.createAnalyser();
            const microphone = audioContext.createMediaStreamSource(audioStream);
            microphone.connect(analyser);

            const bufferLength = analyser.frequencyBinCount;
            const dataArray = new Uint8Array(bufferLength);

            function analyzeAudio() {
                analyser.getByteFrequencyData(dataArray);

                // For now, we mock pitch/timing/duration calculations
                const pitch = 'C4'; // Placeholder for pitch calculation
                const timing = Date.now();
                const duration = 500; // Placeholder for note duration

                // Process the audio data
                const processedData = {
                    pitch: pitch,
                    timing: timing,
                    duration: duration,
                };
                setAudioData([processedData]);
                onAudioProcessed([processedData]);

                requestAnimationFrame(analyzeAudio);
            }

            analyzeAudio();
        }
    }, [audioStream, onAudioProcessed]);

    const startRecording = async () => {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        setAudioStream(stream);
    };

    const stopRecording = () => {
        if (audioStream) {
            const tracks = audioStream.getTracks();
            tracks.forEach(track => track.stop());
            setAudioStream(null);
        }
    };

    return (
        <div>
            <button onClick={startRecording}>Start Recording</button>
            <button onClick={stopRecording}>Stop Recording</button>
            <div>
                <h3>Audio Data:</h3>
                {audioData.map((data, index) => (
                    <div key={index}>
                        <p>Pitch: {data.pitch}</p>
                        <p>Timing: {data.timing}</p>
                        <p>Duration: {data.duration}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AudioProcessing;
