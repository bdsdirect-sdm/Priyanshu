// src/App.tsx

import React, { useState } from 'react';
import FileUpload from './components/FileUpload';
import Music from './components/Music';

const App = () => {
  const [musicXML, setMusicXML] = useState<string>(''); // State to store MusicXML string

  const handleParseXML = (xmlString: string) => {
    setMusicXML(xmlString); // Update musicXML state with parsed XML string
  };

  return (
    <div>
      <FileUpload onParse={handleParseXML} />
      <Music musicXML={musicXML} />
    </div>
  );
};

export default App;
